package types

// const BROKER = "mqtt.eclipseprojects.io"
// const BROKER = "localhost"
const BROKER = "mosquitto"
const PORT = 1885
